#!/usr/bin/env python3
import time
import math
import json
import rclpy
import asyncio
import subprocess
from rclpy.node import Node
from nav_msgs.msg import Odometry
from rclpy.action import ActionClient
from nav2_msgs.action import NavigateToPose

class TurtleControllerNode(Node):
    def __init__(self):
        super().__init__("turtle_controller")
        # Declare initial states for turtlebot.
        self.prev_x = 0
        self.prev_y = 0
        self.current_x = 0
        self.current_y = 0
        self.target_x = 0
        self.target_y = 0
        self.total_distance = 0
        self.is_navigating = False
        self.is_finish = True
        self.is_locking = False
        self.is_straight = True
        self.turtbot_diary  = []
        self.current_status = {}
        # Declare id parameter and connect to turtlebot for controlling.
        self.declare_parameter('id', rclpy.Parameter.Type.INTEGER)    
        self.TB_ID = self.get_parameter('id').value
        self.action_client = ActionClient(self,NavigateToPose, "tb"+str(self.TB_ID)+"/navigate_to_pose")
        self.pose_subscriber = self.create_subscription(Odometry, "/tb"+str(self.TB_ID)+"/odom", self.pose_callback, 10)
        self.get_logger().info("Turtle controller "+str(self.TB_ID)+" has been started.")
        # Initial state.
        self.update_status()
        # self.send_task(-1.0,2.0)

    def pose_callback(self, odom: Odometry):
        # Subcribe the position and orientation information from the odometry topic of turtlebot{id}.
        self.current_x = odom.pose.pose.position.x
        self.current_y = odom.pose.pose.position.y
        #self.get_logger().info(format(self.current_x))
        if(self.total_distance == 0):
            self.prev_x = self.current_x
            self.prev_y = self.current_y

        if self.is_navigating:
            # Obtain current orientation.
            twist = odom.twist.twist.angular.z
            twist_offset = 0.15
            if(abs(twist) < 0.1):
                # Detect forward orientation.
                self.is_straight = True
            if(abs(twist-0.5) < twist_offset and self.is_straight):
                # Broadcast turn left state.
                self.is_straight = False
                self.turtbot_diary=[str(round(self.current_x, 2)),str(round(self.current_y, 2)),str(round(self.total_distance, 2)),"1"]
                self.update_status() 
            if(abs(twist+0.5) < twist_offset and self.is_straight):
                # Broadcast turn right state.
                self.is_straight = False
                self.turtbot_diary=[str(round(self.current_x, 2)),str(round(self.current_y, 2)),str(round(self.total_distance, 2)),"2"]
                self.update_status() 
        else:
            if not self.is_finish:
                # Broadcast complete task
                self.turtbot_diary=[str(round(self.current_x, 2)),str(round(self.current_y, 2)),str(round(self.total_distance, 2)),"3"]
                self.update_status() 
                # Re-initialize variable for next task process
                self.is_finish = True
                self.current_status={} 

        if(self.is_finish):
            time.sleep(3)
            with open('data_'+str(self.TB_ID)+'.json', 'r') as file:
                data = json.load(file)
            if(not data):
                self.get_logger().info("unlock")
                self.unlock()
   
    # Function for sending task for turtlebot.
    def send_task(self, x: float, y: float):
        self.is_navigating = True
        self.is_finish = False
        self.turtbot_diary = []
        goal_msg = NavigateToPose.Goal()
        goal_msg.pose.header.frame_id = "map"
        goal_msg.pose.pose.position.x = x
        goal_msg.pose.pose.position.y = y
        self.target_x = x
        self.target_y = y
        # Broadcast start task state.
        self.turtbot_diary = [str(round(self.current_x, 2)),str(round(self.current_y, 2)),str(round(self.total_distance, 2)),"0"]
        self.update_status() 
        # Create client instance to send navigation goal for turtlebot.
        self.action_client.wait_for_server()
        self.send_goal_future = self.action_client.send_goal_async(goal_msg, feedback_callback=self.feedback_callback)
    # Function for updating position when processing task.
    def feedback_callback(self, feedback_msg):
        x = feedback_msg.feedback.current_pose.pose.position.x
        y = feedback_msg.feedback.current_pose.pose.position.y
        distance_remaining_x = x - self.target_x
        distance_remaining_y = y - self.target_y
        # Calculate total distance that turtlebot has travelled.
        self.total_distance += round(math.sqrt((self.prev_x - x)**2 + (self.prev_y - y)**2),2)
        self.prev_x = x
        self.prev_y = y
        # Detect the state of complete for turtlebot.
        offset = 0.25
        if(abs(distance_remaining_x)<offset and abs(distance_remaining_y)<offset):
            self.is_navigating = False

    # Function for broadcast status to broadcast_status_id channel.
    def update_status(self):
        current_timestamp = int(time.time())
        self.current_status = {
            "is_navigating": self.is_navigating,
            "timestamp": current_timestamp,
            "task":{
                "from":{
                    "x": self.current_x,        
                    "y": self.current_y
                },
                "target":{
                    "x": self.target_x,        
                    "y": self.target_y
                },
                "work_log":self.turtbot_diary
            }     
        }
        self.get_logger().info(format(self.current_status))
        if(self.current_status["task"]["work_log"]):
            # Read the existing JSON data from the file
            with open('data_'+str(self.TB_ID)+'.json', 'r') as file:
                data = json.load(file)

            # Append the new object to the existing data
            data.append(self.current_status)

            # Write the updated data back to the file
            with open('data_'+str(self.TB_ID)+'.json', 'w') as file:
                json.dump(data, file, indent=4)

    def unlock(self):
        try:
            result = subprocess.run(['deno', "run", "--allow-net", "--allow-read" ,"--allow-env",
            'unlock.ts',str(self.TB_ID)], capture_output=True, text=True)
            if "null" not in result.stdout:
                task = result.stdout.split("_")
                hashed_task = str(task[2])
                # Update task list    
                self.add_received_task(hashed_task.strip())
                # Send task base on transaction    
                self.send_task(float(task[0]),float(task[1]))
        except subprocess.CalledProcessError as e:
            print(f"Error executing async function: {e}")

    def add_received_task(self, hashed_task):
        # Read Complete Task List
        with open('data_task_'+str(self.TB_ID)+'.json', 'r') as file:
            data = json.load(file)

        # Append the new object to the existing data
        data.append(hashed_task)

        # Write the updated data back to the file
        with open('data_task_'+str(self.TB_ID)+'.json', 'w') as file:
            json.dump(data, file, indent=4)

# Main Scope==========================================================
def main(args=None):
    # Initialize the ROS Client Library for Python instance
    rclpy.init(args=args)

    # Create an instance of the TurtleControllerNode class
    node = TurtleControllerNode()
    
    # Start the main event loop for the ROS node to handle incoming messages
    rclpy.spin(node)

    # Shutdown the rclpy instance
    rclpy.shutdown()

if __name__ == '__main__':
    main()
