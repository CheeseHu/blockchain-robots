#!/usr/bin/env python3
import time
import math
import json
import rclpy
import subprocess
from rclpy.node import Node


class TurtleDiaryNode(Node):
    def __init__(self):
        super().__init__("turtle_diary")
        # Declare id parameter and connect to turtlebot for controlling.
        self.declare_parameter('id', rclpy.Parameter.Type.INTEGER)    
        self.TB_ID = self.get_parameter('id').value
        self.get_logger().info("Turtle Diary "+str(self.TB_ID)+" has been started.")
        self.diary_process_callback()

    def diary_process_callback(self):
        while(True):
            data = self.read_json_file()
            # Check if there is at least one object in the data
            if data:
                given_timestamp = int(data[0]["timestamp"])
                deviation = given_timestamp - int(time.time())
                with open('data_task_'+str(self.TB_ID)+'.json', 'r') as file:
                    task_list = json.load(file)
                # Record state into blockchain
                self.get_logger().info("start lock")
                self.lock(
                    str(data[0]["task"]["work_log"][0]),
                    str(data[0]["task"]["work_log"][1]),
                    str(data[0]["task"]["work_log"][3]),
                    str(data[0]["task"]["work_log"][2]),
                    str(deviation),
                    str(len(task_list)-1))
                # Remove the first object from the list
                self.get_logger().info("remove data")
                data = self.read_json_file()
                # print(data)
                data.pop(0)

                # Write the updated data back to the file
                with open('data_'+str(self.TB_ID)+'.json', 'w') as file:
                    json.dump(data, file, indent=4)  

    def lock(self,x,y,state,total_distance,deviation,task_id):
        try:
            result = subprocess.run(['deno', "run", "--allow-net", "--allow-read" ,"--allow-env",
            'lock.ts',str(self.TB_ID),x,y,state,total_distance,deviation,task_id], capture_output=True, text=True)
            print(result.stdout)
            # if(result.stdout):
        except subprocess.CalledProcessError as e:
            print(f"Error executing async function: {e}")
        
    def read_json_file(self):
        # Read the existing JSON diary data from the file
        with open('data_'+str(self.TB_ID)+'.json', 'r') as file:
            file_content = file.read()
        # data = json.load(file)
        if file_content.strip() == "[]" or not file_content.strip():  # Check if the file is empty
            data = False
        else:
            data = json.loads(file_content)
        return data
    

# Main Scope==========================================================
def main(args=None):
    # Initialize the ROS Client Library for Python instance
    rclpy.init(args=args)

    # Create an instance of the TurtleDiaryNode class
    node = TurtleDiaryNode()
    
    # Start the main event loop for the ROS node to handle incoming messages
    rclpy.spin(node)

    # Shutdown the rclpy instance
    rclpy.shutdown()

if __name__ == '__main__':
    main()
