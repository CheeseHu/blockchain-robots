import {
  Blockfrost,
  C,
  Data,
  Lucid,
  SpendingValidator,
  TxComplete,
  TxHash,
  TxSigned,
  fromHex,
  toHex,
} from "https://deno.land/x/lucid@0.8.3/mod.ts";
import * as cbor from "https://deno.land/x/cbor@v1.4.1/index.js";
import vesting from "../lib/plutus.json" with { type: "json" };
// function support read validator.
const readValidator = function (): SpendingValidator {
  // Verify validator in plutus.json.
  const vestingValidator = vesting.validators.find(function (validator) {
    return validator.title === "vesting.vesting";
  });

  if (!vestingValidator) {
    throw new Error("Vesting validator not found.");
  }

  // Implement cbor.encode validator according to cbor-x standard code.
  const vestingScript: string = toHex(
    cbor.encode(fromHex(vestingValidator.compiledCode))
  );

  // Return validator plutusV2.
  return {
    type: "PlutusV2",
    script: vestingScript,
  };
};

// Declare datum schema.
const Datum = Data.Object({
  owner: Data.String,
  beneficiary: Data.String,
  target_x: Data.String,
  target_y: Data.String,
  state: Data.String,
  total_distance: Data.String,
  deviation: Data.String,
  task_id: Data.String,
});

type Datum = Data.Static<typeof Datum>;

// Declare list of public address.
const wallet = [
  "addr_test1qz6njjnwfks358yc5n9y6ww9k4puakxghga6lzxczg8p6ynqxdkzs6axwvwa3j7e59xa0pnu5c346n79wcvs66agdxus3gch4h",
  "addr_test1qpxclfxw6mpqrlyu2s9nswpz346akwqyjtdzcf5nax6ktdtxltjy5csvprsktlkjzffw840svjkwksjyysw92pdklf0szcv04r",
  "addr_test1qr3qdanjuw53vzxlmwnnvcreg5l5uvz9y33537x9gh88zwfxke4sfcelxnuafpamyejepews4yxhxwclqhxgynzpyrtslw8m4w",
  "addr_test1qq8v9z34ha08nqjcur3tfmvxdfscwyst8yy67nd7l9gsyphuxu2v95czgm4ddammrqq58fjvjv5nh3xudmqztqnc850sedjzda",
];

// Declare list of seed file for generate owner wallet.
const seed = [
  "../lib/turtlebot0.seed",
  "../lib/turtlebot1.seed",
  "../lib/turtlebot2.seed",
];

type Props = {
  owner: number;
  target_x: any;
  target_y: any;
  state?: any;
  total_distance?: any;
  deviation?: any;
  task_id?: any;
};

const lock = async function ({
  owner,
  target_x,
  target_y,
  state,
  total_distance,
  deviation,
  task_id,
}: Props): Promise<TxHash> {
  // Connect Lucid with preview network in Cardano Blockchain.
  const lucid = await Lucid.new(
  new Blockfrost(
    "https://cardano-preview.blockfrost.io/api/v0",
    "preview549URuNF4vxqAcbww93X0EpqnYejF8bK"
  ),
  "Preview"
);
  // Gernerate Owner wallet based on seed file.
  lucid.selectWalletFromSeed(await Deno.readTextFile(seed[owner]));
  // Assign owner Public Key.
  const ownerPublicKeyHash: string = lucid.utils.getAddressDetails(
    await lucid.wallet.address()
  ).paymentCredential?.hash as string;
  // Assign beneficiary Public Key.
  const beneficiaryPublicKeyHash: string | undefined =
    lucid.utils.getAddressDetails(wallet[0])?.paymentCredential?.hash;
  // Assign Datum.
  const datum = Data.to<Datum>(
    {
      owner: ownerPublicKeyHash ?? "",
      beneficiary: beneficiaryPublicKeyHash ?? "",
      target_x: toHex(cbor.encode(target_x?.toString())),
      target_y: toHex(cbor.encode(target_y?.toString())),
      state: state ? toHex(cbor.encode(state)) : toHex(cbor.encode("")),
      total_distance: total_distance
        ? toHex(cbor.encode(total_distance))
        : toHex(cbor.encode("")),
      deviation: deviation ? toHex(cbor.encode(deviation)) : toHex(cbor.encode("")),
      task_id: task_id ? toHex(cbor.encode(task_id)) : toHex(cbor.encode("")),
    },
    Datum
  );

  const validator = readValidator();
  const contractAddress: string = lucid.utils.validatorToAddress(validator);

  // Owner signs and submits contract to the network.
  const tx: TxComplete = await lucid
    .newTx()
    .payToContract(
      contractAddress,
      { inline: datum },
      { lovelace: BigInt(10000) }
    )
    .complete();

  const signedTx: TxSigned = await tx.sign().complete();
  const txHash: TxHash = await signedTx.submit();

  //waiting for the change in the Blockchain.
  return new Promise((resolve, reject) => {
    const confirmation = setInterval(async () => {
      const isConfirmed = await fetch(
        `https://cardano-preview.blockfrost.io/api/v0/txs/${txHash}`,
        {
          headers: {
            project_id: "preview549URuNF4vxqAcbww93X0EpqnYejF8bK",
            version: "0.10.7",
          },
        }
      ).then((res) => res.json());
      if (isConfirmed && !isConfirmed.error) {
        clearInterval(confirmation);
        await new Promise((res) => setTimeout(() => res(1), 40000)); // delay for 40 seconds
        console.log("is done", txHash);
        return resolve(txHash);
      }
    }, 3000);
  });
  // await new Promise((res) => setTimeout(() => res(1), 10000)); // delay for 10 seconds
  // console.log(`${Deno.args[1]}_${Deno.args[2]}_${Deno.args[3]}_${Deno.args[4]}`);
  //  return "tester"
};

lock( {
  owner: Number(Deno.args[0]),
  target_x: Deno.args[1],
  target_y: Deno.args[2],
  state: Deno.args[3],
  total_distance:Deno.args[4],
  deviation: Deno.args[5],
  task_id:Deno.args[6]
})