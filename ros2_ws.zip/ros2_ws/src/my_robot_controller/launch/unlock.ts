import {
  Blockfrost,
  C,
  Data,
  Lucid,
  SpendingValidator,
  TxComplete,
  TxHash,
  TxSigned,
  fromHex,
  toHex,
  UTxO,
  Datum as DatumType
} from "https://deno.land/x/lucid@0.8.3/mod.ts";
import * as cbor from "https://deno.land/x/cbor@v1.4.1/index.js";
import vesting from "../lib/plutus.json" with { type: "json" };
// function support read validator.
const readValidator = function (): SpendingValidator {
  // Verify validator in plutus.json.
  const vestingValidator = vesting.validators.find(function (validator) {
    return validator.title === "vesting.vesting";
  });

  if (!vestingValidator) {
    throw new Error("Vesting validator not found.");
  }

  // Implement cbor.encode validator according to cbor-x standard code.
  const vestingScript: string = toHex(
    cbor.encode(fromHex(vestingValidator.compiledCode))
  );

  // Return validator plutusV2.
  return {
    type: "PlutusV2",
    script: vestingScript,
  };
};

// Declare list of seed file for generate owner wallet.
const seed = [
  "../lib/turtlebot0.seed",
  "../lib/turtlebot1.seed",
  "../lib/turtlebot2.seed",
];

// Declare datum schema.
const Datum = Data.Object({
  owner: Data.String,
  beneficiary: Data.String,
  target_x: Data.String,
  target_y: Data.String,
  state: Data.String,
  total_distance: Data.String,
  deviation: Data.String,
  task_id: Data.String,
});

type Datum = Data.Static<typeof Datum>;

type Props = {
    owner: number
};
const unlock = async function ({owner}: Props): Promise<TxHash> {
  // Connect Lucid with preview network in Cardano Blockchain.
  const lucid = await Lucid.new(
  new Blockfrost(
    "https://cardano-preview.blockfrost.io/api/v0",
    "preview549URuNF4vxqAcbww93X0EpqnYejF8bK"
  ),
  "Preview"
);
  // Gernerate Owner wallet based on seed file.
  lucid.selectWalletFromSeed(await Deno.readTextFile(seed[owner]));
  // Assign owner Public Key.
  const ownerPublicKeyHash: string = lucid.utils.getAddressDetails(
    await lucid.wallet.address()
  ).paymentCredential?.hash as string;
  const validator = readValidator();
  const contractAddress = lucid.utils.validatorToAddress(validator);
  const scriptUtxos = await lucid.utxosAt(contractAddress);

  // Query the UTxOs that belongs to the owner of the wallet.
  const utxos: UTxO[] = scriptUtxos.filter(function (utxo) {
    if (utxo.datum) {
      let datum = Data.from<Datum>(utxo.datum, Datum);
      return datum.beneficiary === ownerPublicKeyHash;
    }
    // return utxo.txHash == txHash;
  });
  
  if (utxos.length === 0) {
    console.log(
      "null"
    );
    Deno.exit(1);
  }
  const redeemer = Data.empty();
  //Sign and submit contract that consumes the first UTxO to the network.
  const tx: TxComplete = await lucid
    .newTx()
    .collectFrom([utxos[0]], redeemer)
    .addSigner(await lucid.wallet.address())
    .attachSpendingValidator(validator)
    .complete();

  const signedTx: TxSigned = await tx.sign().complete();
  const txHashed: TxHash = await signedTx.submit();
  
  //waiting for the change in the Blockchain.
  return new Promise((resolve, reject) => {
    const confirmation = setInterval(async () => {
      const isConfirmed = await fetch(
        `https://cardano-preview.blockfrost.io/api/v0/txs/${txHashed}`,
        {
          headers: {
            project_id: "preview549URuNF4vxqAcbww93X0EpqnYejF8bK",
            version: "0.10.7",
          },
        }
      ).then((res) => res.json());
      if (isConfirmed && !isConfirmed.error) {
        clearInterval(confirmation);
        await new Promise((res) => setTimeout(() => res(1), 30000)); // delay for 30 seconds
        if(utxos[0].datum){
            const task_x = datumToTask(utxos[0].datum).task_x;
            const task_y = datumToTask(utxos[0].datum).task_y;
            console.log(`${task_x}_${task_y}_${txHashed}`);
        }
        resolve(txHashed);
      }
    }, 3000);
  });
};

// Function supports readable format of datum.
function datumToTask(datum: DatumType) {
  const hexValue_x = toHex(cbor.decode(fromHex(datum)).value[2]);
  const hexValue_y = toHex(cbor.decode(fromHex(datum)).value[3]);

  const task_x = cbor.decode(fromHex(hexValue_x)).toString("utf8");
  const task_y = cbor.decode(fromHex(hexValue_y)).toString("utf8");

  return { task_x, task_y };
}

unlock( {
  owner: Number(Deno.args[0]),
})