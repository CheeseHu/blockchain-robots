from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    ld = LaunchDescription()
    #add nodes for turtlebot 0
    controller_node_0 = Node(
        package="my_robot_controller",
        executable="turtlebot_controller",
        name="controller_0",
        parameters=[
            {"id":0}
        ]
    )

    diary_code_0 = Node(
        package="my_robot_controller",
        executable="turtlebot_diary",
        name="diary_0",
        parameters=[
            {"id":0}
        ]
    )

    #add nodes for turtlebot 1
    controller_node_1 = Node(
        package="my_robot_controller",
        executable="turtlebot_controller",
        name="controller_1",
        parameters=[
            {"id":1}
        ]
    )

    diary_code_1 = Node(
        package="my_robot_controller",
        executable="turtlebot_diary",
        name="diary_1",
        parameters=[
            {"id":1}
        ]
    )

    #add nodes for turtlebot 2
    controller_node_2 = Node(
        package="my_robot_controller",
        executable="turtlebot_controller",
        name="controller_2",
        parameters=[
            {"id":2}
        ]
    )

    diary_code_2 = Node(
        package="my_robot_controller",
        executable="turtlebot_diary",
        name="diary_2",
        parameters=[
            {"id":2}
        ]
    )

    ld.add_action(controller_node_0)
    ld.add_action(diary_code_0)
    ld.add_action(controller_node_1)
    ld.add_action(diary_code_1)
    ld.add_action(controller_node_2)
    ld.add_action(diary_code_2)

    return ld