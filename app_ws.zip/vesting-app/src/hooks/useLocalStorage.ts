import axios from "axios";
import { useState, useEffect } from "react";

const useLocalStorage = (id: number) => {
  const [newdata, setNewData] = useState(null);
  // If there is nothing saved at the start then save an empty array
  useEffect(() => {
    if (localStorage.getItem(`task_tb_${id}`) === null) {
      localStorage.setItem(`task_tb_${id}`, "[]");
    }
  }, []);
  useEffect(() => {
    if (newdata) {
      // Get old data and stop it to the new data
      var old_data = JSON.parse(localStorage.getItem(`task_tb_${id}`));
      old_data.push(newdata);

      // Save the old + new data to local storage
      localStorage.setItem(`task_tb_${id}`, JSON.stringify(old_data));
    }
  }, [newdata]);

  return { setNewData };
};

export default useLocalStorage;
