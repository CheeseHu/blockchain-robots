import { useEffect, useState } from "react";
import { Blockfrost, Lucid } from "lucid-cardano";

// This hook is used for obtain owner wallet.
function UseWallet(ownerSeed: string): {
  lucid: Lucid | undefined;
} {
  // Create Lucid instance.
  const [lucid, setLucid] = useState<Lucid | undefined>();

  useEffect(() => {
    // Connect to preview network of Cardano.
    const connect = async function () {
      try {
        const lucid: Lucid = await Lucid.new(
          new Blockfrost(
            "https://cardano-preview.blockfrost.io/api/v0",
            process.env.REACT_APP_API_KEY
          ),
          "Preview"
        );
        // Create owner wallet from seed.
        lucid.selectWalletFromSeed(ownerSeed);

        setLucid(lucid);
      } catch (error) {
        console.log(error);
      }
    };
    connect();
  }, []);

  return { lucid };
}

export default UseWallet;
