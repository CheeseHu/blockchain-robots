import axios from "axios";
import { useState, useEffect } from "react";
import { ToastContainer, toast } from "react-toastify";

const useMessageBroker = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);

  const getStatus = async (id) => {
    setLoading(true);
    try {
      const response = await axios.get(
        `http://localhost:3333/api/get-status/${id}`
      );
      // console.log("Response:", response.data);
      setData(response.data);
    } catch (error) {
      console.error("Error fetching status:", error);
      // toast.error("Error fetching status!");
    } finally {
      setLoading(false);
    }
  };

  const sendTask = async (id, task) => {
    setLoading(true);
    try {
      const response = await axios.post(
        `http://localhost:3333/api/post-task/${id}?task=${task}`
      );
      console.log("Response:", response.data);
      toast.success("Successfully sent task!");
      // setData(response.data);
    } catch (error) {
      console.error("Error sending task:", error);
      toast.error("Error sending task!");
    } finally {
      setLoading(false);
    }
  };

  return { data, loading, getStatus, sendTask };
};

export default useMessageBroker;
