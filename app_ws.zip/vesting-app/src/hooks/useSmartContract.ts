import { useState, useEffect } from "react";
import lock from "../utils/lock";
import { Entity } from "../utils/select-wallet";
import { Lucid, TxHash } from "lucid-cardano";
import { ToastContainer, toast } from "react-toastify";
import unlock from "../utils/unlock";
import readAllUtxo from "../utils/readAllUtxo";

// This hook is used for interact with the smart contract.
const useSmartContract = () => {
  // State for storing response data from Blockchain.
  const [data, setData] = useState(null);
  // State for handling loading.
  const [loading, setLoading] = useState(false);
  // State for handling type.
  const [type, setType] = useState<"LOCK" | "UNLOCK" | "READ">();
  // State for handling other configurations (datum).
  const [options, setOptions] = useState<{
    lucid: Lucid;
    beneficiary: Entity;
    target_x?: number;
    target_y?: number;
    txHash?: TxHash;
    id?: number;
  }>();
  // Perform action based on configuration.
  const fetchData = async () => {
    setLoading(true);
    try {
      if (type == "LOCK") {
        if (options.target_x && options.target_y) {
          // Create transaction with task datum and Ada.
          const response = await lock({
            ...options,
            target_x: options.target_x,
            target_y: options.target_y,
          });
          toast.success(response);
          setData(response);
        } else {
          setLoading(false);
          toast.error("Target values are missing!");
        }
      } else if (type == "UNLOCK") {
        // Consume UTxO or transaction and reward Ada.
        const response = await unlock({
          lucid: options.lucid,
          txHash: options.txHash,
          id: options.id,
        });
        toast.success("Successfully unlock transaction!");
        setData(response);
      } else if (type == "READ") {
        // Read all UTxOs that can be consumed.
        const response = await readAllUtxo({
          lucid: options.lucid,
          beneficiary: options?.beneficiary,
        });
        toast.success("Successfully read transaction!");
        setData(response);
      }
      // Catch unexpected error.
    } catch (error) {
      setLoading(false);
      console.log(error);
      toast.error(error?.toString());
    } finally {
      setLoading(false);
    }
  };

  return {
    data,
    loading,
    options,
    fetchData,
    setType,
    setOptions,
  };
};

export default useSmartContract;
