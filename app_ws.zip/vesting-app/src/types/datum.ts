import { Data } from "lucid-cardano";

const VestingDatumSchema = Data.Object({
  owner: Data.Bytes(),
  beneficiary: Data.Bytes(),
  target_x: Data.Bytes(),
  target_y: Data.Bytes(),
  state: Data.Bytes(),
  total_distance: Data.Bytes(),
  deviation: Data.Bytes(),
  task_id: Data.Bytes(),
});

type Datum = Data.Static<typeof VestingDatumSchema>;
export const Datum = VestingDatumSchema as unknown as Datum;
