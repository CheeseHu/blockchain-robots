import { Data } from "lucid-cardano";
export const redeemer = Data.void();
