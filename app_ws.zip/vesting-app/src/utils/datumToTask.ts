import { Datum } from "lucid-cardano";
import { toHex, fromHex } from "lucid-cardano";
const cborx = require("cbor-x");
// This functions supports readable datum for list of assignments.
function datumToTask(datum: Datum) {
  const hexValue_x = toHex(cborx.decode(fromHex(datum)).value[2]);
  const hexValue_y = toHex(cborx.decode(fromHex(datum)).value[3]);

  const task_x = cborx.decode(fromHex(hexValue_x)).toString("utf8");
  const task_y = cborx.decode(fromHex(hexValue_y)).toString("utf8");

  return { task_x, task_y };
}
export default datumToTask;
