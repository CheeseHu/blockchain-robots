import { Datum } from "lucid-cardano";
import { toHex, fromHex } from "lucid-cardano";
const cbor = require("cbor-x");
// Convention of name for each robot's state.
const stateEnum = ["Start Task", "Turn Left", "Turn Right", "Done Task"];
// This functions supports readable datum for diary dashboard.
function datumToDiary(datum: Datum) {
  const hexValue_x = toHex(cbor.decode(fromHex(datum)).value[2]);
  const hexValue_y = toHex(cbor.decode(fromHex(datum)).value[3]);
  const hexState = toHex(cbor.decode(fromHex(datum)).value[4]);
  const hexTotalDistance = toHex(cbor.decode(fromHex(datum)).value[5]);
  const hexDeviation = toHex(cbor.decode(fromHex(datum)).value[6]);

  const hexTaskId = toHex(cbor.decode(fromHex(datum)).value[7]);

  const task_x = cbor.decode(fromHex(hexValue_x)).toString("utf8");
  const task_y = cbor.decode(fromHex(hexValue_y)).toString("utf8");
  const state =
    stateEnum[Number(cbor.decode(fromHex(hexState)).toString("utf8"))];
  const totalDistance = cbor.decode(fromHex(hexTotalDistance)).toString("utf8");
  const deviation =
    new Date(
      Math.abs(Number(cbor.decode(fromHex(hexDeviation))) * 1000)
    ).getTime() / 60000;
  const task_id = cbor.decode(fromHex(hexTaskId));

  return { task_x, task_y, state, totalDistance, deviation, task_id };
}
export default datumToDiary;
