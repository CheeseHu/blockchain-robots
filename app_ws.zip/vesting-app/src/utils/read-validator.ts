import { SpendingValidator, fromHex, toHex } from "lucid-cardano";
import { encode } from "cbor-x";
import vesting from "../libs/plutus.json";
// function support read validator.
const readValidator = function (): SpendingValidator {
  console.log(vesting);
  // Verify validator in plutus.json.
  const vestingValidator = vesting.validators.find(function (validator) {
    return validator.title === "vesting.vesting";
  });

  if (!vestingValidator) {
    throw new Error("Vesting validator not found.");
  }

  // Implement cbor.encode validator according to cbor-x standard code.
  const vestingScript: string = toHex(
    encode(fromHex(vestingValidator.compiledCode))
  );

  // Return validator plutusV2.
  return {
    type: "PlutusV2",
    script: vestingScript,
  };
};

export default readValidator;
