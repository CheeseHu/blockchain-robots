import {
  Data,
  Lucid,
  toHex,
  TxComplete,
  TxHash,
  TxSigned,
} from "lucid-cardano";
import { Datum } from "../types/datum";
import readValidator from "../utils/read-validator";
import walletSelector, { Entity } from "./select-wallet";
const cborx = require("cbor-x");

type Props = {
  lucid: Lucid;
  beneficiary: Entity;
  target_x: any;
  target_y: any;
  state?: any;
  total_distance?: any;
  deviation?: any;
  task_id?: any;
};

const lock = async function ({
  lucid,
  beneficiary,
  target_x,
  target_y,
  state,
  total_distance,
  deviation,
  task_id,
}: Props): Promise<TxHash> {
  // Assign owner Public Key.
  const ownerPublicKeyHash: string = lucid.utils.getAddressDetails(
    await lucid.wallet.address()
  ).paymentCredential?.hash as string;
  // Assign beneficiary Public Key.
  const beneficiaryPublicKeyHash: string = walletSelector(beneficiary, lucid);
  // Assign Datum.
  const datum = Data.to(
    {
      owner: ownerPublicKeyHash,
      beneficiary: beneficiaryPublicKeyHash,
      target_x: toHex(cborx.encode(target_x?.toString())),
      target_y: toHex(cborx.encode(target_y?.toString())),
      state: state ? toHex(cborx.encode(state)) : toHex(cborx.encode("")),
      total_distance: total_distance
        ? toHex(cborx.encode(total_distance))
        : toHex(cborx.encode("")),
      deviation: deviation
        ? toHex(cborx.encode(deviation))
        : toHex(cborx.encode("")),
      task_id: task_id ? toHex(cborx.encode(task_id)) : toHex(cborx.encode("")),
    },
    Datum
  );

  const validator = readValidator();
  // Owner signs and submits contract to the network.
  const contractAddress: string = lucid.utils.validatorToAddress(validator);
  const tx: TxComplete = await lucid
    .newTx()
    .payToContract(
      contractAddress,
      { inline: datum },
      { lovelace: BigInt(10000) }
    )
    .complete();

  const signedTx: TxSigned = await tx.sign().complete();
  const txHash: TxHash = await signedTx.submit();
  //waiting for the change in the Blockchain.
  return new Promise((resolve, reject) => {
    const confirmation = setInterval(async () => {
      const isConfirmed = await fetch(
        `https://cardano-preview.blockfrost.io/api/v0/txs/${txHash}`,
        {
          headers: {
            project_id: process.env.REACT_APP_API_KEY,
            version: "0.10.7",
          },
        }
      ).then((res) => res.json());
      if (isConfirmed && !isConfirmed.error) {
        clearInterval(confirmation);
        await new Promise((res) => setTimeout(() => res(1), 30000)); // delay for 30 seconds
        return resolve(txHash);
      }
    }, 3000);
  });
};

export default lock;
