import { Data, Lucid, TxComplete, TxHash, TxSigned, UTxO } from "lucid-cardano";
import { Datum } from "../types/datum";
import readValidator from "./read-validator";
import walletSelector, { Entity } from "./select-wallet";
import { redeemer } from "../types/redeemer";
import datumToTask from "./datumToTask";
import axios from "axios";
import { toast } from "react-toastify";

type Props = {
  lucid: Lucid;
  txHash: TxHash;
  id: number;
};
const unlock = async function ({ lucid, txHash, id }: Props): Promise<TxHash> {
  // Assign owner Public Key.
  const ownerPublicKeyHash: string = lucid.utils.getAddressDetails(
    await lucid.wallet.address()
  ).paymentCredential?.hash as string;
  // Read validator
  const validator = readValidator();
  const contractAddress = lucid.utils.validatorToAddress(validator);
  const scriptUtxos = await lucid.utxosAt(contractAddress);

  // Query the UTxOs that belongs to the owner of the wallet.
  const utxos: UTxO[] = scriptUtxos.filter(function (utxo) {
    let datum = Data.from(utxo.datum!, Datum);
    // return datum.beneficiary === ownerPublicKeyHash && utxo.txHash == txHash;
    return utxo.txHash == txHash;
  });

  //Sign and submit contract that consumes the first UTxO to the network.
  const tx: TxComplete = await lucid
    .newTx()
    .collectFrom(utxos, redeemer)
    .addSigner(await lucid.wallet.address())
    .attachSpendingValidator(validator)
    .complete();

  const signedTx: TxSigned = await tx.sign().complete();
  const txHashed: TxHash = await signedTx.submit();

  //waiting for the change in the Blockchain.
  return new Promise((resolve, reject) => {
    const confirmation = setInterval(async () => {
      const isConfirmed = await fetch(
        `https://cardano-preview.blockfrost.io/api/v0/txs/${txHashed}`,
        {
          headers: {
            project_id: process.env.REACT_APP_API_KEY,
            version: "0.10.7",
          },
        }
      ).then((res) => res.json());
      if (isConfirmed && !isConfirmed.error) {
        clearInterval(confirmation);
        await new Promise((res) => setTimeout(() => res(1), 30000)); // delay for 30 seconds
        const task_x = datumToTask(utxos[0].datum).task_x;
        const task_y = datumToTask(utxos[0].datum).task_y;
        console.log(`${task_x}_${task_y}`);

        //  return txHashed;
        resolve(txHashed);
      }
    }, 3000);
  });
};

export default unlock;
