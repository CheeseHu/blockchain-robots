import { Data, Lucid, TxComplete, TxHash, TxSigned, UTxO } from "lucid-cardano";
import { Datum } from "../types/datum";
import readValidator from "./read-validator";
import walletSelector, { Entity } from "./select-wallet";
import { redeemer } from "../types/redeemer";

type Props = {
  lucid: Lucid;
  beneficiary?: Entity;
};

const readAllUtxo = async function ({
  lucid,
  beneficiary,
}: Props): Promise<UTxO[]> {
  // Assign owner Public Key.
  const ownerPublicKeyHash: string = lucid.utils.getAddressDetails(
    await lucid.wallet.address()
  ).paymentCredential?.hash as string;
  // Read the validator.
  const validator = readValidator();
  const contractAddress = lucid.utils.validatorToAddress(validator);
  const scriptUtxos = await lucid.utxosAt(contractAddress);
  // Query the UTxOs that belongs to the owner of the wallet.
  let utxos: UTxO[];
  if (beneficiary) {
    utxos = scriptUtxos.filter(function (utxo) {
      let datum = Data.from(utxo.datum!, Datum);
      return datum.owner === ownerPublicKeyHash;
      // return true;
    });
  } else {
    utxos = scriptUtxos.filter(function (utxo) {
      let datum = Data.from(utxo.datum!, Datum);
      return datum.beneficiary === ownerPublicKeyHash;
    });
  }

  console.log(utxos);
  return utxos;
};

export default readAllUtxo;
