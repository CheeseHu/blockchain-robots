import { Lucid, SpendingValidator, fromHex, toHex } from "lucid-cardano";
import { encode } from "cbor-x";
export enum Entity {
  MANAGER = 0,
  TURTLEBOT_0 = 1,
  TURTLEBOT_1 = 2,
  TURTLEBOT_2 = 3,
}
const wallet = [
  process.env.REACT_APP_MANAGER_ADDR,
  process.env.REACT_APP_TB0_ADDR,
  process.env.REACT_APP_TB1_ADDR,
  process.env.REACT_APP_TB2_ADDR,
];
const walletSelector = function (beneficiary: Entity, lucid: Lucid): string {
  const response = lucid.utils.getAddressDetails(wallet[beneficiary])
    ?.paymentCredential?.hash;
  return response;
};

export default walletSelector;
