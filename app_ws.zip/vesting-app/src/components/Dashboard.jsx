import React, { useState, useEffect } from "react";
import Card from "./Card.jsx";
//Render 3 cards for 3 robots in main dashboard.
export default function DashBoard() {
  return (
    <div className="flex gap-10">
      <Card id={0} />
      <Card id={1} />
      <Card id={2} />
    </div>
  );
}
