import React, { useEffect, useState } from "react";
import UseWallet from "../hooks/useWallet";
import Button from "./Button";
import useSmartContract from "../hooks/useSmartContract";
// This component is used for rendering form for task allocation.
const TaskAllocationForm = ({ close, id }) => {
  const { lucid } = UseWallet(process.env.REACT_APP_MANAGER_SEED);
  // Create smartContractReader object.
  const smartContract = useSmartContract();
  useEffect(() => {
    if (lucid) {
      smartContract.setType("LOCK");
      smartContract.setOptions({
        lucid: lucid,
        beneficiary: id + 1,
      });
    }
  }, [lucid]);

  // Handle change in x field.
  const handleTargetXChange = (e) => {
    smartContract.setOptions({
      ...smartContract.options,
      target_x: e.target.value,
    });
  };

  // Handle change in y field.
  const handleTargetYChange = (e) => {
    smartContract.setOptions({
      ...smartContract.options,
      target_y: e.target.value,
    });
  };
  // Handle submit task with datum.
  const handleSubmit = (e) => {
    e.preventDefault();
    smartContract.fetchData();
  };

  return (
    <>
      <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-10">
        <div className="bg-white rounded-lg p-8 w-1/2">
          <h2 className="text-lg font-bold mb-4">Task For Turtlebot {id}</h2>
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label
                htmlFor="targetX"
                className="block text-sm font-medium text-gray-700"
              >
                Target X:
              </label>
              <input
                type="text"
                id="targetX"
                value={smartContract?.options?.target_x}
                onChange={handleTargetXChange}
                className="mt-1 block py-3 p-2 w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              />
            </div>
            <div className="mb-4">
              <label
                htmlFor="targetY"
                className="block text-sm font-medium text-gray-700"
              >
                Target Y:
              </label>
              <input
                type="text"
                id="targetY"
                value={smartContract?.options?.target_y}
                onChange={handleTargetYChange}
                className="mt-1 block py-3 p-2 w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              />
            </div>
            <div className="flex justify-end">
              <button
                onClick={() => {
                  smartContract.setOptions({
                    ...smartContract.options,
                    target_x: null,
                    target_y: null,
                  });
                  close();
                }}
                className="font-bold py-2 px-4 text-gray-600 hover:bg-gray-300 bg-gray-200 rounded mr-5"
              >
                Close
              </button>
              <Button
                isLoading={smartContract?.loading}
                buttonText="Create Task"
              />
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default TaskAllocationForm;
