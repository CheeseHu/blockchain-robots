import { useState, useEffect } from "react";
import Button from "./Button";
import TaskAllocationForm from "./TaskAllocationForm";
import TaskManager from "./TaskManager";
// This component is used for rendering card for each robot.
export default function Card({ id }) {
  // State for task assigment form.
  const [taskForm, setTaskForm] = useState(false);
  // State for list of task.
  const [taskList, setTaskList] = useState(false);

  return (
    <div className="space-y-5 group rounded-lg border border-border-gray-200 bg-gray-200 px-5 py-4 transition-colors hover:border-gray-300 hover:bg-gray-100 hover:dark:border-neutral-700 hover:dark:bg-neutral-800/30">
      <div className="flex justify-between">
        <h2 className={`mb-3 text-2xl font-semibold`}>
          TB{id}
          <span className="inline-block transition-transform group-hover:translate-x-1 motion-reduce:transform-none">
            &gt;
          </span>
        </h2>
        <a
          href={`/${id}`}
          className="w-10 h-10 p-2 hover:bg-gray-200 rounded cursor-pointer"
        >
          <img src={"/history.svg"} alt="History Icon" />
        </a>
      </div>
      <div className="flex gap-5">
        <Button
          onClickHandler={() => {
            setTaskForm(true);
          }}
          buttonText="Create Task"
        />
        <Button
          // isDisable={data?.result?.is_navigating || smartContract.loading}
          onClickHandler={() => {
            setTaskList(true);
          }}
          buttonText="Mornitor Task"
        />
      </div>
      {/* Form component is mounted when taskForm is true */}
      {taskForm && (
        <TaskAllocationForm
          isOpen={taskForm}
          close={() => setTaskForm(false)}
          id={id}
        />
      )}
      {/* TaskManager component is mounted when taskList is true */}
      {taskList && (
        <TaskManager
          isOpen={taskForm}
          close={() => setTaskList(false)}
          id={id}
        />
      )}
    </div>
  );
}
