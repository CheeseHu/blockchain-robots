import React, { useEffect, useState } from "react";
import Button from "./Button";
import UseWallet from "../hooks/useWallet";
import useSmartContract from "../hooks/useSmartContract";
import datumToTask from "../utils/datumToTask";
// This component is used for rendering list of assignments.
const TaskManager = ({ close, id }) => {
  // Collect seed file to generate wallet.
  const wallet = [
    process.env.REACT_APP_TB0_SEED,
    process.env.REACT_APP_TB1_SEED,
    process.env.REACT_APP_TB2_SEED,
  ];
  const { lucid } = UseWallet(wallet[id]);
  // Create smartContract object.
  const smartContract = useSmartContract();
  // Create smartContractReader object.
  const smartContractReader = useSmartContract();
  useEffect(() => {
    if (lucid) {
      smartContract.setType("UNLOCK");
      smartContract.setOptions({
        lucid: lucid,
        id: id,
      });
    }
  }, [lucid]);
  // Read all UTxOs belongs to the owner.
  useEffect(() => {
    if (lucid) {
      smartContractReader.setType("READ");
      smartContractReader.setOptions({
        lucid: lucid,
      });
      smartContractReader.fetchData();
    }
  }, [lucid]);
  // Detect select transaction to consume UTxO, mainly for debugging.
  useEffect(() => {
    if (smartContract?.options?.txHash) {
      smartContract.fetchData();
    }
  }, [smartContract?.options?.txHash]);

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-10">
      <div className="space-y-5 bg-white rounded-lg p-8 min-w-[500px] h-2/3 overflow-y-scroll w-fit hide-scrollbar">
        <h2 className="text-lg font-bold mb-4">Task List Turtlebot {id}</h2>
        {smartContractReader.loading && "Loading..."}
        {smartContractReader?.data?.length == 0
          ? "List is empty"
          : smartContractReader?.data?.map?.((utxo) => {
              // console.log(utxo);
              const target = datumToTask(utxo?.datum);
              return (
                <div
                  key={utxo?.txHash}
                  className="flex flex-col border border-black/10 p-5 rounded"
                >
                  <p>#{utxo?.txHash}</p>
                  <div className="flex justify-between">
                    <p>{`Navigate to [${target.task_x}, ${target.task_y}].`}</p>

                    {/* <Button
                      onClickHandler={() => {
                        smartContract.setOptions({
                          ...smartContract.options,
                          txHash: utxo?.txHash,
                          id: id,
                        });
                        // console.log(smartContract.options);
                      }}
                      isDisable={smartContract?.loading}
                      isLoading={
                        smartContract.options.txHash == utxo.txHash &&
                        smartContract?.loading
                      }
                      buttonText="Execute"
                    /> */}
                  </div>
                </div>
              );
            })}
        <div className="flex justify-end">
          <button
            onClick={() => {
              close();
            }}
            className="font-bold py-2 px-4 text-gray-600 hover:bg-gray-300 bg-gray-200 rounded mr-5"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default TaskManager;
