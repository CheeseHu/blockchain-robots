import React, { useState } from "react";
// This component is used for customizing button with title and state.
const Button = ({ onClickHandler, buttonText, isLoading, isDisable }) => {
  return (
    <button
      onClick={onClickHandler}
      className={`${
        isDisable
          ? "bg-blue-100 cursor-not-allowed"
          : "bg-blue-500 hover:bg-blue-700"
      }  text-white font-bold py-2 px-4 rounded`}
      disabled={isLoading || isDisable}
    >
      {isLoading ? "Loading..." : buttonText}
    </button>
  );
};

export default Button;
