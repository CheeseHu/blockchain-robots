import React, { useEffect, useState } from "react";
import Button from "./Button";
import UseWallet from "../hooks/useWallet";
import useSmartContract from "../hooks/useSmartContract";
import datumToTask from "../utils/datumToTask";
import { useParams } from "react-router-dom";
import datumToDiary from "../utils/datumToDiary";
// This component is used for rendering diary of each robot.
const DashboardDiary = () => {
  const { id } = useParams();
  // Collect seed file to generate wallet.
  const wallet = [
    process.env.REACT_APP_TB0_SEED,
    process.env.REACT_APP_TB1_SEED,
    process.env.REACT_APP_TB2_SEED,
  ];
  const { lucid } = UseWallet(wallet[id]);
  // State to show total distance.
  const [totalDistance, setTotalDistance] = useState(0);
  // State to show total task.
  const [taskList, setTaskList] = useState([]);
  // Create smartContractReader object.
  const smartContractReader = useSmartContract();
  useEffect(() => {
    if (lucid) {
      smartContractReader.setType("READ");
      smartContractReader.setOptions({
        lucid: lucid,
        beneficiary: id,
      });
      smartContractReader.fetchData();
    }
  }, [lucid]);
  // Create smartContract object.
  const smartContract = useSmartContract();
  useEffect(() => {
    if (lucid) {
      smartContract.setType("UNLOCK");
      smartContract.setOptions({
        lucid: lucid,
      });
    }
  }, [lucid]);
  // Detect select transaction to consume UTxO, mainly for debugging.
  useEffect(() => {
    if (smartContract?.options?.txHash) {
      smartContract.fetchData();
    }
  }, [smartContract?.options?.txHash]);
  return (
    <div className="space-y-5 bg-white rounded-lg p-10 -w-full h-fulloverflow-y-scroll hide-scrollbar">
      <h2 className="text-lg font-bold mb-4">Diary Turtlebot {id}</h2>
      <p>Total Distance: {totalDistance}</p>
      <p>Total Tasks: {taskList.length}</p>
      {smartContractReader.loading && "Loading..."}
      {smartContractReader?.data?.length == 0
        ? "List is empty"
        : smartContractReader?.data?.map?.((utxo) => {
            const diary = datumToDiary(utxo?.datum);
            if (Number(diary.totalDistance) > totalDistance) {
              setTotalDistance(Number(diary.totalDistance));
            }
            if (!taskList.includes(diary.task_id)) {
              setTaskList([...taskList, diary.task_id]);
            }
            console.log(diary);
            return (
              <div
                key={utxo?.txHash}
                className="flex flex-col border border-black/10 p-5 rounded"
              >
                <p className="opacity-50">#{utxo?.txHash}</p>
                <p>Task Id: {diary.task_id}</p>
                <div className="flex justify-between">
                  <p>{`I ${diary.state} at [${diary.task_x}, ${diary.task_y}].`}</p>
                  <p>{`Delay ${diary.deviation.toFixed(2)} mins`}</p>

                  {/* <Button
                    onClickHandler={() => {
                      smartContract.setOptions({
                        ...smartContract.options,
                        txHash: utxo?.txHash,
                        id: id + 1,
                      });
                      // console.log(smartContract.options);
                    }}
                    isDisable={smartContract?.loading}
                    isLoading={
                      smartContract.options.txHash == utxo.txHash &&
                      smartContract?.loading
                    }
                    buttonText="debug"
                  /> */}
                </div>
              </div>
            );
          })}
    </div>
  );
};

export default DashboardDiary;
