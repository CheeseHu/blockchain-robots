import { Button, Dashboard } from "./components";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useEffect } from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import DashboardDiary from "./components/DashboarDiary";
export default function App() {
  return (
    <Router>
      <main className="flex min-h-screen flex-col items-center justify-between p-24 space-y-10">
        <h1 className="text-[5.25rem] font-semibold relative flex place-items-center before:absolute before:h-[300px] before:w-full sm:before:w-[480px] before:-translate-x-1/2 before:rounded-full before:bg-gradient-radial before:from-white before:to-transparent before:blur-2xl before:content-[''] after:absolute after:-z-20 after:h-[180px] after:w-full sm:after:w-[240px] after:translate-x-1/3 after:bg-gradient-conic after:from-sky-200 after:via-blue-200 after:blur-2xl after:content-[''] before:dark:bg-gradient-to-br before:dark:from-transparent before:dark:to-blue-700 before:dark:opacity-10 after:dark:from-sky-900 after:dark:via-[#0141ff] after:dark:opacity-40 before:lg:h-[360px] z-[-1]">
          Turtlebots Dashboard
        </h1>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/:id" element={<DashboardDiary />} />
        </Routes>
        <ToastContainer />
      </main>
    </Router>
  );
}
